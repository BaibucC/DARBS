'use strict';

var moment = require('moment');
var rome = require('./rome');

rome.use(moment);

module.exports = rome;
